package com.Groceries.dt;

import com.Groceries.Model.CartModel;
import com.Groceries.Model.CustomerDetails;
import com.Groceries.Model.GroceryModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class OrderRequest {
 public GroceryModel Grocery;
 public CartModel products;
 public CustomerDetails customer;


public CartModel getProducts() {
	return products;
}

public OrderRequest(GroceryModel grocery, CartModel products, CustomerDetails customer) {
	super();
	Grocery = grocery;
	this.products = products;
	this.customer = customer;
}

public CustomerDetails getCustomer() {
	return customer;
}

public void setCustomer(CustomerDetails customer) {
	this.customer = customer;
}

public void setProducts(CartModel products) {
	this.products = products;
}

public OrderRequest(GroceryModel grocery, CartModel products) {
	super();
	Grocery = grocery;
	this.products = products;
}

public void setGrocery(GroceryModel grocery) {
	Grocery = grocery;
}

public GroceryModel getGrocery() {
	// TODO Auto-generated method stub
	return Grocery;
}

public OrderRequest() {
	super();
}

public OrderRequest(GroceryModel grocery) {
	super();
	Grocery = grocery;
}

public void assignCartValue(GroceryModel grocery2) {
this.setGrocery(Grocery);	
}


}
