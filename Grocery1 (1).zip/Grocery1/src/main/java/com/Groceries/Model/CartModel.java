package com.Groceries.Model;



import java.io.IOException;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;



@Entity
@Table(name="products7")
public  class CartModel {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int pid;

	int id;
	
	String title;
		int price;
		int quantity;
		String photo;
		String category;
		String email;

public CartModel() {
			
		}
		public CartModel(int pid, int id, String title, int price, int quantity, String photo, String category,
				String email, int total,String date) {
			super();
			this.pid = pid;
			this.id = id;
			this.title = title;
			this.price = price;
			this.quantity = quantity;
			this.photo = photo;
			this.category = category;
			this.email = email;
			this.total = total;
		}

		
		
		
////		@OneToMany(fetch = FetchType.EAGER,mappedBy="employee",cascade = CascadeType.ALL)	
//		@ManyToOne(cascade=CascadeType.ALL)
//		@JoinColumn(name="email")
//		private GroceryModel grocery;
		
		public String getEmail() {
			return email;
		}




		public void setEmail(String email) {
			this.email = email;
		}




		public int getPid() {
			return pid;
		}
		public void setPid(int pid) {
			this.pid = pid;
		}
//		public GroceryModel getGrocery() {
//			return grocery;
//		}
//		public void setGrocery(GroceryModel grocery) {
//			this.grocery = grocery;
//		}

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public String getPhoto() {
			return photo;
		}
		public void setPhoto(String photo) {
			this.photo = photo;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public int getTotal() {
			return total;
		}
		public void setTotal(int total) {
			this.total = total;
		}
		int total;
		
		
		
		
		
		
//		@Override
//		public void serialize(JsonGenerator gen, SerializerProvider serializers) throws IOException {
//			// TODO Auto-generated method stub
//			
//		}
//		@Override
//		public void serializeWithType(JsonGenerator gen, SerializerProvider serializers, TypeSerializer typeSer)
//				throws IOException {
//			// TODO Auto-generated method stub
//			
		}
//		public void assignCartValue(GroceryModel grocery) {
//			this.grocery=grocery;
//		}
//		public void assignCartValue1(GroceryModel grocery) {
//			
//		}
//		public void add(GroceryModel grocery) {
//			this.grocery=grocery;
//			// TODO Auto-generated method stub
//			
//		}

