//package com.Groceries.Model;
//
//import java.util.HashSet;
//import java.util.Set;
//
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.ManyToMany;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="answer")
//public class AnswerModel {
//	@Id
//	@GeneratedValue(generator="incrementId")
//    public int id;
//    public String answer;
//    @ManyToMany(mappedBy = "answer")
//    private Set<AdminLoginModel> recordings = new HashSet<>();
//
//	public AnswerModel() {
//		super();
//	}
//	public AnswerModel(int id, String answer) {
//		super();
//		this.id = id;
//		this.answer = answer;
//	}
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getAnswer() {
//		return answer;
//	}
//	public void setAnswer(String answer) {
//		this.answer = answer;
//	}
//	
//}
