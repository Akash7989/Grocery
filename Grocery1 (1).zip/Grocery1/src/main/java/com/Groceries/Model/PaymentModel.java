package com.Groceries.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="payment4")
public class PaymentModel {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
int payid;
	String accountholdername;
	String cardnumber;
	String expiry;
	String email;
	String delivery;
	String address;
	long contact;
	public String getDelivery() {
		return delivery;
	}
	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public PaymentModel() {
		super();
	}
	public int getPayid() {
		return payid;
	}
	public void setPayid(int payid) {
		this.payid = payid;
	}
	public String getAccountholdername() {
		return accountholdername;
	}
	public void setAccountholdername(String accountholdername) {
		this.accountholdername = accountholdername;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getItemAmount() {
		return itemAmount;
	}
	public void setItemAmount(int itemAmount) {
		this.itemAmount = itemAmount;
	}
	public PaymentModel(int payid, String accountholdername, String cardnumber, String email, int cvv, String date,String delivery,String address,long contact,
			int itemAmount,String expiry) {
		super();
		this.expiry=expiry;
		this.delivery=delivery;
		this.address=address;
		this.contact=contact;
		this.payid = payid;
		this.accountholdername = accountholdername;
		this.cardnumber = cardnumber;
		this.email = email;
		this.cvv = cvv;
		this.date = date;
		this.itemAmount = itemAmount;
	}
	public String getExpiry() {
		return expiry;
	}
	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}
	int cvv;
	String date;
	int itemAmount;
	





}
