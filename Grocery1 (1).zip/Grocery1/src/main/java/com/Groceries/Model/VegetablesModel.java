package com.Groceries.Model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import javax.persistence.JoinColumn;



@Entity
@Table(name="wholeProductList1")

public class VegetablesModel {
	@Id
@GeneratedValue(generator="incrementId")
	int id;
	int price;
	int quantity;
	String photo;
	String title;
	String category;
	String email;
	int discount;
	
//	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
//	@JoinTable(name="product_images",
//	joinColumns= {
//			@JoinColumn(name="id")
//			 },
//	inverseJoinColumns= {
//			@JoinColumn(name="iid")
//	}
//	)
//	private Set<ImageModel>productImages;
//	
//	
//	public Set<ImageModel> getProductImages() {
//		return productImages;
//	}
//	public void setProductImages(Set<ImageModel> productImages) {
//		this.productImages = productImages;
//	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public VegetablesModel() {
	}
	public VegetablesModel(int id, int price, String email,String photo, String title,String category,int quantity,int discount) {
		super();
		this.email=email;
		this.id = id;
		this.quantity=quantity;
		this.price = price;
		this.photo = photo;
		this.title = title;
		this.category=category;
		this.discount=discount;
		
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCateogry(String category) {
		this.category = category;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}