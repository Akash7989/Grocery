package com.Groceries.Model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customerDetails")
public class CustomerDetails {
	@Id
	@GeneratedValue(generator="incrementId")
	private int cid;
	private String username;
	private int contactNo;
	private String address;
	
	public CustomerDetails(int cid, String username, int contactNo, String address, List<CartModel> products) {
		super();
		this.cid = cid;
		this.username = username;
		this.contactNo = contactNo;
		this.address = address;
//		this.products = products;
	}
public CustomerDetails() {
		
	}
	
	public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public int getContactNo() {
	return contactNo;
}
public void setContactNo(int contactNo) {
	this.contactNo = contactNo;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

//	@OneToMany(targetEntity=CartModel.class,cascade=CascadeType.ALL)
//	@JoinColumn(name="forkey",referencedColumnName="cid")
//	private List<CartModel> products;

//	public List<CartModel> getProducts() {
//		return products;
//	}
//	public void setProducts(List<CartModel> products) {
//		this.products = products;
//	}
//	
//	

}
