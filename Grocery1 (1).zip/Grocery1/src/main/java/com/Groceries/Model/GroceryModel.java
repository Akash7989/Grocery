package com.Groceries.Model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.web.bind.annotation.Mapping;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="customers3")
public class GroceryModel{
	@Id
	String email;
	
	String password;
	String contact;
	String username;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public GroceryModel() {
		super();
	}
	public GroceryModel(String email, String password, String contact, String username) {
		super();
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.username = username;
	}
	


	
//	public Set<CartModel> getCart() {
//		return cart;
//	}
//	public List<CartModel> getProducts() {
//		return products;
//	}
////
//	public void setProducts(List<CartModel> products) {
//		this.products = products;
//	}

//	public void setCart(Set<CartModel> cart) {
//		this.cart = cart;
//	}}
//    	@OneToMany(targetEntity=CartModel.class,cascade=CascadeType.ALL)
//	@JoinColumn(name="forkey",referencedColumnName="email")
//	private List<CartModel> products;
//}



}

    

    
//@Entity
//@Table(name="storekeeper")
//public class GroceryModel {
//	@Id
//	
//	String storename;
//	String ownername;
//	int fssai;
//
//	String address;
//	long contact;
//	public int getFssai() {
//		return fssai;
//	}
//	public void setFssai(int fssai) {
//		this.fssai = fssai;
//	}
//	public String getStorename() {
//		return storename;
//	}
//	public void setStorename(String storename) {
//		this.storename = storename;
//	}
//	public String getOwnername() {
//		return ownername;
//	}
//	public void setOwnername(String ownername) {
//		this.ownername = ownername;
//	}
//	public String getAddress() {
//		return address;
//	}
//	public void setAddress(String address) {
//		this.address = address;
//	}
//	public long getContact() {
//		return contact;
//	}
//	public void setContact(long contact) {
//		this.contact = contact;
//	}
//	
//
//}
