package com.Groceries.Controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.Groceries.Exception.ResourceNotFoundException;


import com.Groceries.DOA.CustomerDOA;
import com.Groceries.DOA.GroceryByEmailDOA;
import com.Groceries.DOA.GroceryDOA;
import com.Groceries.DOA.cartDOA;
import com.Groceries.Model.AdminLoginModel;
import com.Groceries.Model.CartModel;
import com.Groceries.Model.CustomerDetails;
import com.Groceries.Model.GroceryModel;
import com.Groceries.Model.VegetablesModel;
import com.Groceries.dt.OrderRequest;


@RestController
//@CrossOrigin(origins="*")

public class CartController {
	@Autowired
	cartDOA cd;
	@Autowired
	GroceryDOA gd;
	@Autowired
	CustomerDOA csd;

//@PostMapping("/placeOrder")	
//public GroceryModel placeOrder(@RequestBody OrderRequest request) {
//	return gd.save(request.getGrocery());
//}
//@PostMapping("/placeOrders")	
//public CustomerDetails placeOrders(@RequestBody OrderRequest request) {
//	return csd.save(request.getCustomer());
//}
//@PostMapping("/placeOrderss")
//public CustomerDetails custmoerCheck(@RequestBody OrderRequest userData1)
//{
//	GroceryModel user1=new GroceryModel();
//	CustomerDetails userData2=new CustomerDetails();
//	System.out.println(user1);
//	System.out.println(user1.getUsername());
//
//	if(user1.getUsername().equals(userData2.getUsername())){
//		System.out.println(user1);
//		return csd.save(userData1.getCustomer());
//	}
//		else {
//			return null;
//		}
//	
//	}
//	return(ResponseEntity<?> ResponseEntity.internalServerError())
//if(user1.getPassword().equals(userData1.getPassword()))
//	return ResponseEntity.ok(user1);
//return (ResponseEntity<?>) ResponseEntity.internalServerError();
//	
//}

@GetMapping("/findAllOrders")
public List<GroceryModel>findAllOrders(){
	return gd.findAll();
}
//
//	@PutMapping("/cart/{pid}/grocery/{email}")
//	public CartModel assignCart(
//		@PathVariable int pid,
//		@PathVariable String email){
//	CartModel cart=cd.findById(pid).get();
//	GroceryModel grocery=gd.findByEmail(email);
//	System.out.println(email);
//	 cart.assignCartValue(grocery);
//	
//	return cd.save(cart);
//}
		@PostMapping("/cart")
	@CrossOrigin(origins="http://localhost:4200")

public void addcart(@RequestBody CartModel c[])  {
		for(int i=0;i<c.length;i++)
		
		cd.save(c[i]);
		}

		@GetMapping("/showCart")
		@CrossOrigin(origins="http://localhost:4200")

		public List<CartModel> findAllOrderss(){
		return cd.findAll();
		}
		
//		@PostMapping("viewapp1")
//		@CrossOrigin(origins="http://localhost:4200")

//		public Iterator<CartModel> getAppointmentByEmail(String email1) {
//			GroceryModel email1=getEmail();
//			System.out.println("email1");
//		List<CartModel> gm=cd.findByEmail(email1);
//		return gm.iterator();
//			
//		}
		
		
//		@DeleteMapping("/deleteproduct/{mid}")
//		public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable int mid){
//			CartModel menu = cd.findById(mid)
//					.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + mid));
//			
//			md.delete(menu);
//			Map<String, Boolean> response = new HashMap<>();
//			response.put("deleted", Boolean.TRUE);
//			return ResponseEntity.ok(response);
//		}
		}



//	
//	}

	


