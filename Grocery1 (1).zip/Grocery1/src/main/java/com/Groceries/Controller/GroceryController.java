package com.Groceries.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Groceries.DOA.AdminDOA;
import com.Groceries.DOA.GroceryByEmailDOA;
import com.Groceries.DOA.GroceryDOA;
import com.Groceries.Model.AdminLoginModel;
import com.Groceries.Model.GroceryModel;
import com.Groceries.Model.VegetablesModel;
import com.Groceries.Service.GroceryService;
import com.Groceries.Service.VegetablesService;



@RestController
@CrossOrigin(origins="http://localhost:4200")

public class GroceryController {
	@Autowired
	GroceryService gs;

	

	@PostMapping("/insert")
	@CrossOrigin(origins="http://localhost:4200")
	

	public void save(@RequestBody GroceryModel g) throws Exception {
		String tempEmailId=g.getEmail();
		if(tempEmailId !=null && !"".equals(tempEmailId)) {
			GroceryModel gobj=gs.fetchUserByEmail(tempEmailId);
		if(gobj !=null) {
			throw new Exception("user with"+tempEmailId+" already exist");
			}
		
		}
		
		gs.saveUser(g);
		
	}
	
	
	@GetMapping("email")
	@CrossOrigin(origins="http://localhost:4200")
	public List<GroceryModel>getPlayer(){
		return gs.getAllPlayer();
	}

	
	@Autowired
	private GroceryDOA gDOA1;
	@Autowired
	private AdminDOA gDOA;
	
	@PostMapping("login")
	@CrossOrigin(origins="http://localhost:4200")
//	public ResponseEntity<?>loginUser(@RequestBody AdminLoginModel userData1)
//	{
//		AdminLoginModel user1=gDOA.findByEmail(userData1.getEmail());
//		System.out.println(user1);
//	if(user1.getPassword().equals(userData1.getPassword()))
//		return ResponseEntity.ok(user1);
//	return (ResponseEntity<?>) ResponseEntity.internalServerError();
//		
//	}
	public ResponseEntity<?>loginUser(@RequestBody GroceryModel userData)
	{
		GroceryModel user3=gDOA1.findByEmail(userData.getEmail());
		System.out.println(user3);
	if(user3.getPassword().equals(userData.getPassword()))
		return ResponseEntity.ok(user3);
	return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}

//	@Autowired
//	private GroceryDOA gDOA1;
//	@PostMapping("usercheckanswer")
//	@CrossOrigin(origins="http://localhost:4200")

//	public ResponseEntity<?>answerVerify1(@RequestBody GroceryModel userData2){
//		GroceryModel user=gDOA1.findByEmail(userData2.getEmail());
//		System.out.println(user);
//		if(user.getAnswer().equals(userData2.getAnswer()))
//			return ResponseEntity.ok(user);
//		return (ResponseEntity<?>) ResponseEntity.internalServerError();
//
//	}
	
	
	
	@PostMapping("useranswer")
	@CrossOrigin(origins="http://localhost:4200")
	
	public void saveAdmin(@RequestBody GroceryModel g) {
		{  
		gs.saveOrUpdate(g);  
		  
		}  
		
		
		
	}
//	@GetMapping("/player/{email}")
//	@CrossOrigin(origins="http://localhost:4200")
//
////	public GroceryModel getPlayer(@PathVariable String email){
//////		return gDOA1.getOne(email);
//////		return gDOA1.findByEmail(email);
//
//////		return cd.getPlayerById(id);
////	}
	
	@PostMapping("viewapp")
	@CrossOrigin(origins="http://localhost:4200")

	public GroceryModel getAppointment(@RequestBody GroceryModel email) {
	String email1=email.getEmail();
	return gs.getAppointmentByEmail(email1);
//	public List<GroceryModel>getCustomer(){
//		return vvs.getAllPlayer();
//	}

}
	@GetMapping("customerDet")
	public List<GroceryModel> getPlayers(){
		return gs.getAllPlayer();
	}	



}


