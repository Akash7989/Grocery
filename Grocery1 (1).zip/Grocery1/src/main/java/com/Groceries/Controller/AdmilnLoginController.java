package com.Groceries.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Groceries.DOA.AdminDOA;
import com.Groceries.Model.AdminLoginModel;
import com.Groceries.Model.GroceryModel;
import com.Groceries.Service.AdminLoginService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AdmilnLoginController {
	@Autowired
	AdminLoginService as;
	@PostMapping("admindata")
	public void saveAdmin(@RequestBody AdminLoginModel ad) {
		{  
		as.saveOrUpdate(ad);  
		  
		}  
		
		
		
	}
		
		
	
	
	
	@Autowired
	private AdminDOA gDOA;
	
	@PostMapping("adminlogin")

	public ResponseEntity<?>loginUser(@RequestBody AdminLoginModel userData1)
	{
		AdminLoginModel user1=gDOA.findByEmail(userData1.getEmail());
		System.out.println(user1);
	if(user1.getPassword().equals(userData1.getPassword()))
		return ResponseEntity.ok(user1);
	return (ResponseEntity<?>) ResponseEntity.internalServerError();
		
	}
	@PostMapping("checkanswer")
	public ResponseEntity<?>answerVerify(@RequestBody AdminLoginModel userData2){
		AdminLoginModel user2=gDOA.findByEmail(userData2.getEmail());
		System.out.println(user2);
		if(user2.getAnswer().equals(userData2.getAnswer()))
			return ResponseEntity.ok(user2);
		return (ResponseEntity<?>) ResponseEntity.internalServerError();

	}
	
}

