//package com.Groceries.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.Groceries.DOA.GroceryDOA;
//import com.Groceries.DOA.answerDOA;
//import com.Groceries.Model.AnswerModel;
//import com.Groceries.Model.GroceryModel;
//import com.Groceries.Service.AnswerService;
//
//@RestController
//public class AnswerController {
//	@Autowired
//	AnswerService as;
//	@PostMapping("answer")
//	@CrossOrigin(origins="http://localhost:4200")
////	public void saveAnswer(@RequestBody AnswerModel a)throws Exception{
//		as.saveanswer(a);
//	}
//
//
//
//}
////public void save(@RequestBody GroceryModel g) throws Exception {
////	String tempEmailId=g.getEmail();
////	if(tempEmailId !=null && !"".equals(tempEmailId)) {
////		GroceryModel gobj=gs.fetchUserByEmail(tempEmailId);
////	if(gobj !=null) {
////		throw new Exception("user with"+tempEmailId+" already exist");
////		}
////	
////	}
////	
////	gs.saveUser(g);
////	
////}