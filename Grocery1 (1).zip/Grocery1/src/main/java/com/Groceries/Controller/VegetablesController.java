package com.Groceries.Controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.Groceries.DOA.VegetablesDOA;
import com.Groceries.DOA.cartDOA;
import com.Groceries.Exception.ResourceNotFoundException;
import com.Groceries.Model.ImageModel;
import com.Groceries.Model.VegetablesModel;
import com.Groceries.Service.VegetablesService;


@RestController
//@CrossOrigin(origins="*")
public class VegetablesController {
	@Autowired
	VegetablesService vs;
//	@PostMapping(value={"/products"}, consumes= {MediaType.MULTIPART_FORM_DATA_VALUE})
//	@CrossOrigin(origins="http://localhost:4200")
//
//	public VegetablesModel save(@RequestPart
//			("product")
//	VegetablesModel v
//			,
//			@RequestPart("imageFile")CommonsMultipartFile[] file)
//	{
//		try {
//			Set<ImageModel> images=uploadImage(file);
//			v.setProductImages(images);
//			return vs.addNewProduct(v);
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//			return null;
//		}
//		
//	}
	public Set<ImageModel> uploadImage(MultipartFile[] multipartFiles)throws IOException{
//	@PostMapping("products")
	Set<ImageModel> imageModels=new HashSet<>();
	for(MultipartFile file:multipartFiles) {
		ImageModel imageModel =new ImageModel(file.getOriginalFilename(), file.getContentType(),file.getBytes());
		imageModels.add(imageModel);
	}
	return imageModels;
	}
	
	
	
	@Autowired
	VegetablesService vss;
	@Autowired
	VegetablesDOA vd;
	
	@PostMapping("products")
	@CrossOrigin(origins="http://localhost:4200")
	public void save(@RequestBody VegetablesModel v)throws Exception{
		
		vss.saveProduct(v);
	}
	@Autowired
	VegetablesService vvs;
	@GetMapping("view")
	@CrossOrigin(origins="http://localhost:4200")

	//@RequestMapping(value="/player",method=RequestMethod.GET)
	public List<VegetablesModel>getPlayer(){
		return vvs.getAllPlayer();
	}
	
	
	@PostMapping("deletemenu")
	@CrossOrigin(origins="http://localhost:4200")
	public void deleteM(@RequestBody VegetablesModel id) {
		System.out.println(id);
		vs.deleteMenu(id.getId());
	}
	
	@PutMapping("/updatemenu/{id}")
	public ResponseEntity<VegetablesModel> updateEmployee(@PathVariable int id, @RequestBody VegetablesModel v){
		VegetablesModel menu = vd.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		menu.setTitle(v.getTitle());
		menu.setPrice(v.getPrice());
		
		
		VegetablesModel updatedmenu = vd.save(menu);
		return ResponseEntity.ok(updatedmenu);
	}
	
		
	}



