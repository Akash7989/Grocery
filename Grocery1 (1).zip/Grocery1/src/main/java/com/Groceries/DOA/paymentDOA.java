package com.Groceries.DOA;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Groceries.Model.PaymentModel;

public interface paymentDOA  extends JpaRepository<PaymentModel,Integer>{

}
