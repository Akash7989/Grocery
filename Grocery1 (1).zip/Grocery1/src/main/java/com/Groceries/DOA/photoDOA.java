//package com.Groceries.DOA;
//
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.Groceries.Model.photoModel;
//
//public interface photoDOA extends JpaRepository<photoModel,String>{
//	Optional<photoModel> findByName(String name);
//}
//
