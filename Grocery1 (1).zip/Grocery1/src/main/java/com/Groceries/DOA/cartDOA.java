package com.Groceries.DOA;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.Groceries.Model.CartModel;
import com.Groceries.Model.GroceryModel;

public interface cartDOA extends JpaRepository<CartModel,Integer> {

	public CartModel findById(int pid);

	public List<CartModel> findByEmail(String email1);

//	CartModel saveAll(CartModel[] cart);

//@Transactional
//@Modifying	
//@Query("update CartModel c set c.category = :category where c.pid = :pid")
//void updateEmail(@Param(value = "pid") long id, @Param(value = "category") String email);
//	CartModel save(CartModel[] cart);



}
