package com.Groceries.DOA;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Groceries.Model.AdminLoginModel;

public interface AdminDOA extends JpaRepository<AdminLoginModel,String>{

	public AdminLoginModel findByEmail(String email);

}
