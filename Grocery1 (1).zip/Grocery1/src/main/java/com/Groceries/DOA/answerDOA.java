//package com.Groceries.DOA;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.Groceries.Model.AnswerModel;
//
//public interface answerDOA extends JpaRepository<AnswerModel,Integer> {
//
//	AnswerModel findByAnswer = null;
//
//	AnswerModel findById(String answer);
//
//	AnswerModel findByAnswer(String answer);
//
//	AnswerModel findByEmail(String answer);
//
//	
//
//	 
//	
//
//}
