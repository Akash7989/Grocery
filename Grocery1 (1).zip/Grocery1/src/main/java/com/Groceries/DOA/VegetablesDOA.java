package com.Groceries.DOA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.Groceries.Model.VegetablesModel;
//import org.springframework.data.jpa.repository.JpaRepository;



public interface VegetablesDOA extends JpaRepository<VegetablesModel, Integer>{

	void deleteByTitle(VegetablesModel v);

	
	

}
