package com.Groceries.DOA;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Groceries.Model.GroceryModel;

public interface GroceryByEmailDOA extends JpaRepository<GroceryModel, String> {

	Optional<GroceryModel> findByEmail(String email1);

}
