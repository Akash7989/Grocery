package com.Groceries.DOA;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Groceries.Model.CustomerDetails;

public interface CustomerDOA extends JpaRepository<CustomerDetails,Integer>{

}
