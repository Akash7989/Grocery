package com.Groceries.DOA;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Groceries.Model.GroceryModel;


public interface GroceryDOA extends JpaRepository<GroceryModel,String>{

//	public Optional<GroceryModel> findByEmail(String email);
	public GroceryModel findByEmail(String email);


}
