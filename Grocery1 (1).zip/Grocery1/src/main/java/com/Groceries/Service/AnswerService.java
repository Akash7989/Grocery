//package com.Groceries.Service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.Groceries.DOA.answerDOA;
//import com.Groceries.Model.AnswerModel;
//@Service
//public class AnswerService {
//	
//	@Autowired
//	answerDOA ad;
//
//	public void saveanswer(AnswerModel a) {
//		ad.save(a);
//		
//	}
////
//}