package com.Groceries.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Groceries.DOA.GroceryByEmailDOA;
import com.Groceries.DOA.GroceryDOA;
import com.Groceries.Model.AdminLoginModel;
import com.Groceries.Model.GroceryModel;

@Service
public class GroceryService {
	@Autowired
	GroceryDOA gd;
	
	
	/*public void saveUser(GroceryModel g) {
	  gd.save(g);
	}*/
	public void saveUser(GroceryModel g) {
		// TODO Auto-generated method stub
		gd.save(g);
	}
	public GroceryModel fetchUserByEmail(String email) {
		return gd.findByEmail(email);
	}
//	public GroceryModel fetchUserByEmailAndPassword(String email, String password) {
//		return gd.findByEmailAndPassword(email,password);
//	}
	
	public void saveOrUpdate(GroceryModel g)   
	{  
		gd.save(g);  
	}
	public List<GroceryModel> getAllPlayer() {
		return gd.findAll();

	}
	
	@Autowired
	GroceryByEmailDOA ged;
	public GroceryModel getAppointmentByEmail(String email1) {
		Optional<GroceryModel> gm=ged.findByEmail(email1);
		if(gm.isPresent()) {
			return gm.get();
		}
		return null;
	}
//	public bookAppointmentModel getAppointmentById(int appointment_id) {
//		
//		Optional<bookAppointmentModel> pm=bad.findById(appointment_id);
//		if(pm.isPresent()) {
//			//System.out.println(pm.get().getName());
//			return pm.get();
//		}else 
//		return null;
//	}
//	public GroceryModel getAppointmentByEmail(String email1) {
//		// TODO Auto-generated method stub
//		return null;
	}
	

