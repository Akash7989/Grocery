package com.Groceries.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Groceries.DOA.AdminDOA;
import com.Groceries.Model.AdminLoginModel;
import com.Groceries.Model.GroceryModel;
@Service
public class AdminLoginService {
	 List<AdminLoginModel> list=new ArrayList<AdminLoginModel>();

@Autowired
 AdminDOA ado;
	
	public void saveOrUpdate(AdminLoginModel ad)   
	{  
		ado.save(ad);  
	}  
//		public void update(AdminLoginModel a, String email)   
//		{  
//		ado.save(a);  
//		}

		public AdminLoginModel fetchUserByEmail(String email) {
			// TODO Auto-generated method stub
			return ado.findByEmail(email);
		}

		 		
	}


