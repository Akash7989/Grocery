//package com.Groceries.Service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.Groceries.DOA.cartDOA;
//import com.Groceries.Model.CartModel;
//import com.Groceries.Model.VegetablesModel;
//
//@Service
//public class CartService {
//	@Autowired
//	cartDOA cd;
//	CartModel c;
//	public List<CartModel> getAllPlayer() {
//		
//		
//	}
//	
//	
//}
