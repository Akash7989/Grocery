package com.Groceries.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Groceries.DOA.VegetablesDOA;
import com.Groceries.Model.VegetablesModel;
@Service
public class VegetablesService {
@Autowired	
	VegetablesDOA vd;

	
	public void saveProduct(VegetablesModel v) {
		vd.save(v);
	}


	public List<VegetablesModel> getAllPlayer() {
		// TODO Auto-generated method stub
		return vd.findAll();
	}


	public VegetablesModel addNewProduct(VegetablesModel v) {
		return vd.save(v);
	}


	public void deleteMenu(int i) {
		vd.deleteById(i);
	}


	

	

}
